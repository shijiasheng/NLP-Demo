Contents of ``appveyor`` are from https://github.com/ogrisel/python-appveyor-demo
License: CC0 1.0 Universal
